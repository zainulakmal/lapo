/*Driver App Configuration*/

var krms_driver_config ={		
	'ApiUrl':"",	
	'DialogDefaultTitle':"DriverApp",	
	'PushProjectID':"",	
	'APIHasKey':""
};